//
//  AppICEInboxMessage.h
//  iosAppiceSDK
//
//  Created by Mac on 12/20/19.
//  Copyright © 2019 Semusi. All rights reserved.
//  Aditya Sharma

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AppICEInboxMessage : NSObject

//extern const int ALL;

@property (strong, nonatomic) NSString *messageId;
@property (strong, nonatomic) NSString *messageMid;
@property (strong, nonatomic) NSString *messageImage;
@property (strong, nonatomic) NSString *messageBody;
@property (strong, nonatomic) NSString *messageTitle;
@property (strong, nonatomic) NSString *messageStatus;
@property (strong, nonatomic) NSString *messageLanguage;
@property (strong, nonatomic) NSString *messageCampid;
@property (strong, nonatomic) NSMutableDictionary *customData;
@property (nonatomic) double messageExpiryTime;
@property (strong, nonatomic) NSString *campType;


+(AppICEInboxMessage*)instanceFromDictionary:(NSDictionary *)aDictionary;

//- (void)setAttributesFromDictionary:(NSDictionary *)aDictionary;
- (void)setAttributesFromDictionary:(NSDictionary *)aDictionary :(AppICEInboxMessage*)instance;
+(NSString*)toJson:(NSMutableArray*)inbox;

-(NSMutableDictionary*)mediaData:(NSString *)mediaKey;
-(NSString*)mediaUrl:(NSDictionary*)mediaData;
-(NSString*)mediaType:(NSDictionary*)mediaData;
-(NSString*)mediaThumbnail:(NSDictionary*)mediaData;
@end


NS_ASSUME_NONNULL_END
